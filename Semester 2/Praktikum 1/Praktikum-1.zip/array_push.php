<!DOCTYPE html>
<html lang="en">
<?php
    $tims = ['erwin', 'heru', 'ali', 'zaki'];
    array_push($tims, 'wati');
    foreach($tims as $person){
        echo $person. '<br/>';
    }
?>
<body>
    
</body>
</html>