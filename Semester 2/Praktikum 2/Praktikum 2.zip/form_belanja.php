<!DOCTYPE html>
<html lang="id">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <h1>Belanja Online</h1>
    <hr/>
    <div class="container-fluid">
        <div class="row">
            <div class="col-8">
                <form method="POST" action="form_belanja.php">
                    <div class="form-group row">
                        <label for="customer" class="col-4 col-form-label">Customer</label> 
                        <div class="col-8">
                        <input id="customer" name="customer" placeholder="Nama Customer" type="text" class="form-control">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-4">Pilih Produk</label> 
                        <div class="col-8">
                        <div class="custom-control custom-radio custom-control-inline">
                            <input name="produk" id="produk_0" type="radio" class="custom-control-input" value="TV"> 
                            <label for="produk_0" class="custom-control-label">TV</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input name="produk" id="produk_1" type="radio" class="custom-control-input" value="Kulkas"> 
                            <label for="produk_1" class="custom-control-label">Kulkas</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input name="produk" id="produk_2" type="radio" class="custom-control-input" value="MesinCuci"> 
                            <label for="produk_2" class="custom-control-label">Mesin Cuci</label>
                        </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="jumlah" class="col-4 col-form-label">Jumlah</label> 
                        <div class="col-8">
                        <input id="jumlah" name="jumlah" placeholder="Jumlah Produk" type="text" class="form-control">
                        </div>
                    </div> 
                    <div class="form-group row">
                        <div class="offset-4 col-8">
                        <button type="submit" name="proses" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-4">
                <table class="table">
                    <tbody>
                    <tr class="table-primary">
                        <th scope="col">Daftar Harga</th>
                    </tr>
                    <tr>
                        <td scope="row">TV : 4.200.000</td>
                    </tr>
                    <tr>
                        <td scope="row">Kulkas : 3.100.000</td>
                    </tr>
                    <tr>
                        <td scope="row">Mesin Cuci : 3.800.000</td>
                    </tr>
                    <tr class="table-primary">
                        <th scope="col">Harga Dapat Berubah Setiap Saat</th>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <hr/>

    <?php
        $customer = $_POST['customer'];
        $produk = $_POST['produk'];
        $jumlah = $_POST['jumlah'];
        $proses = $_POST['proses'];

        switch ($produk) {
            case 'TV' :
                $harga = 4200000;
                $harga = $harga * $jumlah;
                echo 'Nama Customer : '. $customer;
                echo '<br>Produk yang dibeli : '. $produk;
                echo '<br>Jumlah Produk yang dibeli : '. $jumlah;
                echo '<br>Total Belanja : '. number_format ($harga,0,',','.') . ",-";
                break;

            case 'KULKAS' :
                $harga = 3100000;
                $harga = $harga * $jumlah;
                echo 'Nama Customer : '. $customer;
                echo '<br>Produk yang dibeli : '. $produk;
                echo '<br>Jumlah Produk yang dibeli : '. $jumlah;
                echo '<br>Total Belanja : '. number_format ($harga,0,',','.') . ",-";
                break;

            case 'MESIN CUCI' :
                $harga = 3800000;
                $harga = $harga * $jumlah;
                echo 'Nama Customer : '. $customer;
                echo '<br>Produk yang dibeli : '. $produk;
                echo '<br>Jumlah Produk yang dibeli : '. $jumlah;
                echo '<br>Total Belanja : '. number_format ($harga,0,',','.') . ",-";
                break;

            default :
                # code...
                break;
        }
    ?>
</body>
</html>